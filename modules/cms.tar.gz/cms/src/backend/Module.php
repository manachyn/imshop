<?php

namespace im\cms\backend;

use Yii;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'im\cms\backend\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
