<?php

namespace im\cms\components;

trait PageTrait
{

} 