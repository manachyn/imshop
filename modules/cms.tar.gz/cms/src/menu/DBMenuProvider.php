<?php

namespace im\cms\menu;

class DBMenuProvider implements MenuProviderInterface {

    /**
     * @inheritdoc
     */
    public function getMenuItems($menuType)
    {
        // TODO: Implement getMenuItems() method.
    }
}