<?php

namespace im\cms\menu;

class FileMenuProvider implements MenuProviderInterface {

    /**
     * @inheritdoc
     */
    public function getMenuItems($menuType)
    {
        // TODO: Implement getMenuItems() method.
    }
}